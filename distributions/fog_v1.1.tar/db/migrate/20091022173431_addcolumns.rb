class Addcolumns < ActiveRecord::Migration
  def self.up

    add_column :prov_xns, :userclass, :string
    add_column :prov_xns, :mailhost, :string

  end

  def self.down
  end
end
