
export RUBYLIB=.:./lib:./test
