require 'test_helper'

class ProvXnsHelperTest < ActionView::TestCase
end
